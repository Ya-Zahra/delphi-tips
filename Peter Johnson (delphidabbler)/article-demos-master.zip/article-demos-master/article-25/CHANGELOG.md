# Article #25 Demo Changelog

## v1.1 of 2007/05/20

* Changed implementation of TCustomDropTarget.CanDrop in `./4/UCustomDropTarget.pas`.

## v1.0 of 2007/04/22

* Original version.
