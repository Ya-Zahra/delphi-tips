# License for Article 13 demo code

This demo code is licensed under the [MIT License](https://github.com/delphidabbler/article-demos/blob/master/MIT-License.md).
