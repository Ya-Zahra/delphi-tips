# License for Article 14 demo code

This demo code is licensed under the [MIT License](https://github.com/delphidabbler/article-demos/blob/master/MIT-License.md), with the exception of `UWebBrowserWrapper.pas`. See the header comments in `UWebBrowserWrapper.pas` for details of the license that applies to that file.
