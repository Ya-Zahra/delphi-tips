# License for Article 8 demo code

The demo code is licensed under the [MIT License](https://github.com/delphidabbler/article-demos/blob/master/MIT-License.md), with the exception of `PJDropFiles.pas`. See the header comments in `PJDropFiles.pas` for details of the license that applies to that file.
