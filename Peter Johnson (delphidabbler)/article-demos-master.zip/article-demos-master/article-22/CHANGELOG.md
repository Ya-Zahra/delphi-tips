# Article #22 Demo Changelog

## v1.1.1 of 2022/06/12

* Changed example DelphiDabbler programs displayed in the demo HTML file.
* Minor changes to modernise the demo HTML file
* Corrected program URLs dislayed in main form.
* Updated README.md and ReadMe.html re changes.

## v1.1 of 2006/02/01

* Renamed `IntfUIHandlers.pas` as `IntfDocHostUIHandler.pas`
* Rewrote `IntfDocHostUIHandler.pas` and `UNulContainer.pas` based on units of the same name in the article "[How to call Delphi code from scripts running in a TWebBrowser](https://delphidabbler.com/articles/article-22)"
* Modified other code to use the renamed and rewritten units.

## v1.0 of 2005/05/09

* Original version
