# License for Article 18 demo code

The demo code is licensed under the [MIT License](https://github.com/delphidabbler/article-demos/blob/master/MIT-License.md), with the exception of `IntfDocHostUIHandler.pas` which is licensed under the [Mozilla Public License v2.0](https://www.mozilla.org/en-US/MPL/2.0/).
