# Article #18 Demo Changelog

## v2.3 of 2010-05-30

* Enabled compilation with Delphi's after v7 by adding required project files and groups.
* IntfDocHostUIHandler.pas changed to MPL/GPL/LGPL tri-license and fixed some errors.
* Added project file for later Delphis.
* Removed duplication of DlgContent.html file.
* Added batch file to remove binaries and temporary editing files.
* Added disclaimers to source code.
* Updated documentation.

## v2.2 of 2008-04-14

* Revised IntfUIHandlers.pas:
  * Incorporated new DOCHOSTUIFLAG_ flags introduced in IE7.
  * Added value for DOCHOSTUIFLAG_ flags that had erroneous values.

## v2.1 of 2006-02-11

* Revised IntfUIHandlers.pas based on unit of same name from article #22 demo.

## v2.0 of 2006-02-06

* Revised Demo 2 to use new UContainer and UNulContainer units.

## v1.2 of 2006-01-29

* Moved Demo 2 UI handler units to same folder as form.

## v1.1 of 2005-05-09

* New stand-alone IntfUIHandlers.pas unit in demo 2.

## v1.0 of 2004-11-30

* Original version.
