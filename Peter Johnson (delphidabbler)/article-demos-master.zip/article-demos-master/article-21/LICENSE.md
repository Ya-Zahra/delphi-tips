# License for Article 21 demo code

There are two demo projects, each written by different authors, under different terms.

* The code in the `CaseStudy` folder is licensed under the [MIT License](https://github.com/delphidabbler/article-demos/blob/master/MIT-License.md).

* The code in the `ReturnValue` folder is copyright (c) 2009, Christian Sciberras. _You are free to use the source code in any way you wish at your own risk. Credits would be appreciated but are not required._
