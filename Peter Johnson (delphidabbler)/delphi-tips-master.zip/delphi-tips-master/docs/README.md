# Delphi Tips Project Website

This directory contains a Jekyl project that builds the [Delphi Tips](https://tips.delphidabbler.com) website that is hosted on GitHub Pages.
