# articles

PDFs containing articles from the old delphidabbler.com website.

***TEMPORARY REPO - PLEASE DO NOT FORK or CLONE***

This repo has been set up to preserve the articles that would otherwise have been lost with the 15 June 2020 closure of the old delphidbbler web server. It is planned that the web versions will be re-established at some point on the replacement [delphidabbler.com](https://delphidabbler.com) site. For now that site links to articles in this repo.

***If and when all the articles have been restored, this repo will be deleted.***
